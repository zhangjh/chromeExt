## [聚合翻译](https://chrome.google.com/webstore/detail/%E8%81%9A%E5%90%88%E7%BF%BB%E8%AF%91/dojcmeeckecghjmochpgmppfefgkfian?hl=zh-CN)
源于谷歌翻译正式退出中国，后续日常使用中对于翻译的需求，除了网站不能使用，chrome的谷歌翻译扩展也不能正常使用了。。

正好自己还有台vps，日常除了搭建开源服务、科学上网之外，也没啥其他用途了，正好可以用来作为谷歌翻译的服务中转机器，于是有了这个项目。

这个项目主要为了实现chrome的划线翻译、主动翻译功能，同时聚合了国内主流翻译引擎：百度、有道，以及Bing的翻译功能，所以取名聚合翻译。

## 功能使用演示
- 点击扩展按钮主动翻译

  <img src="https://user-images.githubusercontent.com/3371714/194800001-f1c84c75-504b-4d23-b146-d56563362bfc.jpg" width="400" />
  <img src="https://user-images.githubusercontent.com/3371714/194800018-2162466a-ee37-4afa-a8e3-87d024f2090f.jpg" width="400" />

- 页面划线翻译

  <img src="https://user-images.githubusercontent.com/3371714/194797949-5ffabcaf-bc81-40d3-b660-3b66310d0f84.jpg" width="500" />
- 右键菜单跳转网站翻译
  暂未单独制作承载落地页，仅引导跳转到百度翻译
  
  <img src="https://user-images.githubusercontent.com/3371714/194790545-5b8d1973-bdbb-476b-9235-54e605e24202.jpg" width="500" />
